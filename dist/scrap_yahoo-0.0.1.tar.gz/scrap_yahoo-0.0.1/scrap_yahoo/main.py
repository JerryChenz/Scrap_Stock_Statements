import scrap_mod

if __name__ == '__main__':
    print(scrap_mod.get_forex_rate('HKD','USD'))
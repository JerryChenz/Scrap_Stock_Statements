from scrap_mod import get_forex_rate
from scrap_mod import scrap_data
from scrap_mod import _parse_table
from scrap_mod import get_income_statement
from scrap_mod import get_balance_sheet

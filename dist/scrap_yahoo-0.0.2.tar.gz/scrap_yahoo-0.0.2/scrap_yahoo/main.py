from scrap_yahoo import get_forex_rate

if __name__ == '__main__':
    print(get_forex_rate('HKD', 'USD'))